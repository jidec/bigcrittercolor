from bigcrittercolor.maskfilter import clusterMasksExtractSegs

def test_clusterextract_default():
    clusterMasksExtractSegs(img_ids=None,filter_hw_ratio_minmax=(3, 100),filter_prop_img_minmax=(0, 0.25),
                       data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")

def test_clusterextract_trimsides():
    clusterMasksExtractSegs(img_ids=None,filter_hw_ratio_minmax=(3, 100),filter_prop_img_minmax=(0, 0.25),
                       data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")

test_clusterextract_default()