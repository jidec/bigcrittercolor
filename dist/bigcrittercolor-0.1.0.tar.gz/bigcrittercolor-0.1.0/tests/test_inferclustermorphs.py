#from bigcrittercolor.morphcluster import inferClusterViewsMorphs
import os

def test_inferclustermorphs():
    inferClusterViewsMorphs(img_ids=None,records_group_col="species", data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")
#test_inferclustermorphs()