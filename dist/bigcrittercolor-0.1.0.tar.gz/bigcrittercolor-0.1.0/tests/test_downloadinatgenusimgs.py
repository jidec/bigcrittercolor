from bigcrittercolor.imgdownload import downloadiNatGenusImages
import os

def test_downloadinatgenusimgs():
    downloadiNatGenusImages(start_index=9,end_index=10, img_size="square",data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_data_folder")
test_downloadinatgenusimgs()