from bigcrittercolor.dataprep import printBCCDataStatus

def test_getstatus():
    printBCCDataStatus("D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")
test_getstatus()
