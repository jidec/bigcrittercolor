from bigcrittercolor.helpers import _rebuildiNatRecords
import os

def test_rebuildrecords():
    _rebuildiNatRecords(data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")
#test_rebuildrecords()