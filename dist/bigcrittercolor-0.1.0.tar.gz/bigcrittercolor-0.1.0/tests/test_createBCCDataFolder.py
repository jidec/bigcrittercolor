from bigcrittercolor.dataprep import createBCCDataFolder

def test_createbccfolder():
    createBCCDataFolder(parent_folder="D:/GitProjects/bigcrittercolor/tests", new_folder_name= "dummy_bcc_folder")
test_createbccfolder()
