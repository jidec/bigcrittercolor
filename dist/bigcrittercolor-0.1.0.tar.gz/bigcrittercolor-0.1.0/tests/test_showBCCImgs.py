from bigcrittercolor.helpers import showBCCImages

def test_showbccimgs():
    showBCCImages(sample_n=2, img_ids=None, show_type="img_mask", data_folder="D:/GitProjects/bigcrittercolor/tests/dummy_bcc_folder")

test_showbccimgs()