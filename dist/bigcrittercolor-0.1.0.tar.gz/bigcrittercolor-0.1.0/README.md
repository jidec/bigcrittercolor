# bigcrittercolor
 
Current paradigms:
1. No explicit .csv record is kept of downloaded, stored, or processed images,
an ID'd image being somewhere is already a record. 
An ID being in all_images means it was downloaded.
An ID being in masks means it was masked. 
An ID being in segments means it was clustered and segmented. 
An ID being in inferences.csv means that it was clustered for view and morph

Weirdness arises when you consider that you could 
