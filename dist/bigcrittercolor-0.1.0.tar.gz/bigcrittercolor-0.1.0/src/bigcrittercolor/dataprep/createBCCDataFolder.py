import os

def createBCCDataFolder(parent_folder, new_folder_name="inat-dragonfly_data"):

    base_path = parent_folder + "/" + new_folder_name

    # make folder
    os.mkdir(base_path)

    # make images folders
    os.mkdir(base_path + "/all_images")
    os.mkdir(base_path + "/segments")
    os.mkdir(base_path + "/masks")
    os.mkdir(base_path + "/patterns")

    # make other folder
    os.mkdir(base_path + "/other")

    # make inat_genus_download_records folder
    os.mkdir(base_path + "/other/inat_genus_download_records")

    # make raw records folder
    os.mkdir(base_path + "/other/raw_records")