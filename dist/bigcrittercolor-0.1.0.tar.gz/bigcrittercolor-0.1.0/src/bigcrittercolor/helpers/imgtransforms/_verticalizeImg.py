import numpy as np
import cv2
from bigcrittercolor.helpers.imgtransforms import _vertUsingLine, _getLongestLineThruBlob2, _getBlobEllipseLine, _narrowToBoundingRect, _flipHeavyToTop
from bigcrittercolor.helpers.imgtransforms._getBlobEllipseLine import _getBlobEllipseLine
from bigcrittercolor.helpers.imgtransforms._cropImgSides import _cropImgSides

# verticalize an image either using an ellipse or using the longest blob axis
# COLOR IMAGE is taken
# happens to wrap trim sides on axis functionality, may want to separate that out
def _verticalizeImg(img, by_ellipse=False, trim_sides_on_axis_size = None, show=False):
  if show:
    cv2.imshow("Start Image",img)
    cv2.waitKey(0)
  start_img = np.copy(img)

  greyu8 = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY).astype(np.uint8)

  if by_ellipse:
    line = _getBlobEllipseLine(greyu8)
  else:
    line = _getLongestLineThruBlob2(greyu8,show=show)

  img = _vertUsingLine(img,line)

  img = _narrowToBoundingRect(img)

  img = _flipHeavyToTop(img)

  if trim_sides_on_axis_size is not None:
    white_pixel_indices = np.where(img != 0)
    highest_white_pixel_y = np.min(white_pixel_indices[0])
    highest_white_pixel_x = np.min(white_pixel_indices[1][np.where(white_pixel_indices[0] == highest_white_pixel_y)])
    img = _cropImgSides(img, middle_x=highest_white_pixel_x,lr_crop_px=trim_sides_on_axis_size)

  return img