
def _bprint(b, s):
    if b: print(s)