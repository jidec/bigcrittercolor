from bigcrittercolor import createBCCDataFolder, downloadiNatImageData

#createBCCDataFolder("E:/","dragonflies")
#taxa = ["Harmonia axyridis","Trichiotinus piger", "Synolabus nigripes", "Osmoderma scabra"]
#downloadiNatImageData(taxa_list=taxa,n_per_taxon=10,data_folder="E:/dragonflies")