from bigcrittercolor import clusterExtractSegs

clusterExtractSegs(img_ids=None, used_aux_segmodel=True,
                   filter_hw_ratio_minmax=(3,100),
                   data_folder="E:/aeshna_data")
